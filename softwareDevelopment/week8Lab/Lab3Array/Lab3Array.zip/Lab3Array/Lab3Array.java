package softwareDevelopment.week8Lab.Lab3Array;

public class Lab3Array {
    public static void main(String[] args) {
        int[][] array = {
                { 1, 2, 3 },
                { 4, 5, 6 },
                { 7, 8, 9 }
        };

        int[] rowSums = new int[array.length];
        int[] columnSums = new int[array[0].length];
        int totalSum = 0;

        System.out.println("Array: ");

        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                System.out.print(array[i][j] + " ");

                rowSums[i] += array[i][j];
                columnSums[j] += array[i][j];
                totalSum += array[i][j];
            }

            System.out.println();
        }

        // print row sums
        for (int i = 0; i < rowSums.length; i++) {
            System.out.println("sum row " + (i + 1) + ": " + rowSums[i]);
        }

        // print column sums
        for (int j = 0; j < columnSums.length; j++) {
            System.out.println("sum column " + (j + 1) + ": " + columnSums[j]);
        }

        // print total sum the array
        System.out.println("sum the entire array: " + totalSum);
    }
}
