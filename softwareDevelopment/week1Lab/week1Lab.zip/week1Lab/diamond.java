public class Diamond {
    public static void main(String[] args) {
        String[] pattern = {"  *", " * *", "* * *", " * *", "  *"};
        // loop each position in the array
        for(String p : pattern) System.out.println(p);
    }
}
