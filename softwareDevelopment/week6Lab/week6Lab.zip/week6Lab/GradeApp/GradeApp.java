package softwareDevelopment.week6Lab.GradeApp;

import java.util.Scanner;

public class GradeApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("how many subjects do you take? ");
        int numberOfSubjects = scanner.nextInt();

        if (numberOfSubjects < 1) {
            System.out.println("no subjects to be graded");
            return;
        } else if (numberOfSubjects > 10) {
            System.out.println("limit number of subject reached max: 10");
            return;
        }

        double totalMarks = 0;
        for (int i = 1; i <= numberOfSubjects; i++) {
            System.out.print("enter the mark for subject " + i + " (0-100): ");
            double mark = scanner.nextDouble();
            while (mark < 1 || mark > 100) {
                System.out.println("invalid mark. Please enter a value between 0 and 100.");
                System.out.print("enter the mark for subject " + i + " (0-100): ");
                mark = scanner.nextDouble();
            }
            totalMarks += mark;
        }

        // calculate average
        double average = totalMarks / numberOfSubjects;
        System.out.println("average result: " + average);

        if (average >= 90) {
            System.out.println("your grade: A");
        } else if (average >= 80) {
            System.out.println("your grade: B");
        } else if (average >= 70) {
            System.out.println("your grade: C");
        } else if (average >= 60) {
            System.out.println("your grade: D");
        } else if (average >= 50) {
            System.out.println("your grade: E");
        } else {
            System.out.println("your grade: F");
        }
    }
}
